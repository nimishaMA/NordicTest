import Thingy from "./js/Thingy.js";

export default Thingy;
